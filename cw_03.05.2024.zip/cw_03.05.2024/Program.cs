﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace cw_03._05._2024
{
    internal class Program
    {
        static int RemotePort;
        static int LocalPort;
        static IPAddress RemoteIP;
        static string Name;
        static void Main(string[] args)
        {
            try
            {
                Console.SetWindowSize(40, 20);
                Console.Title = "Chat";
                Console.Write("Введите удалённый IP: ");
                RemoteIP = IPAddress.Parse(Console.ReadLine());
                Console.Write("Введите удалённый порт: ");
                RemotePort = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите локальный порт: ");
                LocalPort = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите своё имя: ");
                Name = Console.ReadLine();
                Thread thread = new Thread(new ThreadStart(ReceiveThread));
                thread.IsBackground = true;
                thread.Start();
                Console.ForegroundColor = ConsoleColor.Red;
                while (true)
                {
                    SendData(Console.ReadLine());
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Преобразование невозможно: " + ex.Message);
            }
            catch (SocketException ex)
            {
                Console.WriteLine("Ошибка соединения: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void ReceiveThread()
        {
            UdpClient uClient = new UdpClient(LocalPort);
            try
            {
                while (true)
                {
                    IPEndPoint ipEnd = null;
                    byte[] responce = uClient.Receive(ref ipEnd);
                    string fullMessage = Encoding.Unicode.GetString(responce);

                    Console.ForegroundColor = ConsoleColor.Yellow; // Предположим, имя будет в этом цвете
                    Console.WriteLine(fullMessage); // Здесь предполагается, что строка уже содержит имя: сообщение
                    Console.ResetColor(); // Сброс цвета обратно к стандартному
                }
            }
            catch (SocketException ex)
            {
                Console.WriteLine("Ошибка соединения: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                uClient.Close();
            }
        }
        static void SendData(string datagram)
        {
            using (UdpClient uClient = new UdpClient())
            {
                IPEndPoint ipEnd = new IPEndPoint(RemoteIP, RemotePort);
                try
                {
                    string fullMessage = Name + ": " + datagram; // Объединение имени и сообщения
                    byte[] bytes = Encoding.Unicode.GetBytes(fullMessage);
                    uClient.Send(bytes, bytes.Length, ipEnd);
                }
                catch (SocketException ex)
                {
                    Console.WriteLine("Ошибка соединения: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
