﻿using NAudio.Wave;
using System;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Windows;

namespace VoiceClient
{
    public partial class MainWindow : Window
    {
        private TcpClient client;
        private WaveInEvent waveSource;
        private bool isRecording = false;

        public MainWindow()
        {
            InitializeComponent();
            ConnectToServer();
        }

        private async void ConnectToServer()
        {
            if (client == null || !client.Connected)
            {
                client = new TcpClient();
                await client.ConnectAsync("127.0.0.1", 5000);
                Console.WriteLine("Connected to server.");
            }
        }

        private void StartRecording(object sender, RoutedEventArgs e)
        {
            if (isRecording)
                return;

            ConnectToServer();

            waveSource = new WaveInEvent();
            waveSource.WaveFormat = new WaveFormat(44100, 1);
            waveSource.DataAvailable += OnDataAvailable;
            waveSource.StartRecording();
            isRecording = true;
        }

        private void OnDataAvailable(object sender, WaveInEventArgs e)
        {
            if (client?.Connected ?? false)
            {
                client.GetStream().WriteAsync(e.Buffer, 0, e.BytesRecorded);
            }
        }

        private void StopRecording(object sender, RoutedEventArgs e)
        {
            if (!isRecording)
                return;

            waveSource?.StopRecording();
            waveSource?.Dispose();
            waveSource = null;

            client?.Close();
            isRecording = false;
        }
    }
}
