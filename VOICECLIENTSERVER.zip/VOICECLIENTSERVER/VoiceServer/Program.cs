﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using NAudio.Wave;
using System.Threading.Tasks;

namespace VoiceServer
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var listener = new TcpListener(IPAddress.Any, 5000);
            listener.Start();
            Console.WriteLine("Server started...");

            try
            {
                while (true)
                {
                    var client = await listener.AcceptTcpClientAsync();
                    Console.WriteLine("Client connected.");
                    _ = ProcessClientAsync(client);
                }
            }
            finally
            {
                listener.Stop();
            }
        }

        private static async Task ProcessClientAsync(TcpClient client)
        {
            using (client)
            {
                var stream = client.GetStream();
                var buffer = new byte[1024];
                int bytesRead;
                string fileName = $"Audio_{DateTime.Now.Ticks}.wav";
                using (var waveFile = new WaveFileWriter(fileName, new WaveFormat(44100, 1)))
                {
                    while ((bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    {
                        waveFile.Write(buffer, 0, bytesRead);
                        Console.WriteLine($"Received {bytesRead} bytes");
                    }
                }
                Console.WriteLine($"Recording saved as {fileName}.");
            }
        }
    }
}
