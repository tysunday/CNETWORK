﻿using System.Net.Sockets;
using System.Text;
using System.Net;
using System.Runtime.ExceptionServices;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography.X509Certificates;

namespace TryTcpp
{
    internal class Program
    {
        static TcpListener l;
        public enum Item
        {
            stone = 1,
            scissors = 2,
            papper = 3
        };

        static void Main(string[] args)
        {
            try
            {
                string ipAddressStr = "127.0.0.1";
                int port = 20000;

                l = new TcpListener(IPAddress.Parse(ipAddressStr), port);
                l.Start();
                Thread thread = new Thread(
                    new ThreadStart(ServerThread)
                    );
                thread.IsBackground = true;
                thread.Start();
                string command;
                do
                {
                    command = Console.ReadLine();

                } while (command != "stop" && command != "quit");
                l.Stop();
            }
            catch (SocketException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.BackgroundColor = ConsoleColor.White;
                Console.WriteLine($"Ошибка сети: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.BackgroundColor = ConsoleColor.White;
                Console.WriteLine($"Ошибка: {ex.Message}");
            }

            static void ServerThread()
            {
                int count = 0;
                while (count != 5)
                {
                    int choose = 0;
                    int choose2 = 0;
                    while (choose == 0 || choose2 == 0)
                    {
                        TcpClient clientFirst = l.AcceptTcpClient();
                        StreamReader sr = new StreamReader(
                            clientFirst.GetStream(),
                            Encoding.Unicode);
                        string s = sr.ReadLine();
                        choose = Convert.ToInt32(s);
                        clientFirst.Close();
                        Console.WriteLine((Item)choose);

                        TcpClient clientSecond = l.AcceptTcpClient();
                        StreamReader sr2 = new StreamReader(
                            clientSecond.GetStream(),
                            Encoding.Unicode);
                        string s2 = sr2.ReadLine();
                        choose2 = Convert.ToInt32(s2);
                        clientSecond.Close();
                        Console.WriteLine((Item)choose2);
                        if (Battle(choose, choose2))
                            count++;
                    }
                }
            }



            static bool Battle(int first, int second)
            {
                if (first > 0 && first < 4 && second > 0 && second < 4)
                {
                    Item one = (Item)first;
                    Item two = (Item)second;
                    Console.WriteLine($"Player1 move = {one}. Player2 move = {two}");
                    if (one == two)
                        Console.WriteLine("NoOneWin");
                    else if (one == Item.stone && two == Item.papper)
                        Console.WriteLine("Win player2");
                    else if (one == Item.scissors && two == Item.stone)
                        Console.WriteLine("Win player2");
                    else if (one == Item.papper && two == Item.scissors)
                        Console.WriteLine("Win player2");
                    else
                        Console.WriteLine("Win player1");
                    return true;
                }
                else
                {
                    Console.WriteLine("Not valid value!");
                    return false;
                }
            }
        }
    }
}

