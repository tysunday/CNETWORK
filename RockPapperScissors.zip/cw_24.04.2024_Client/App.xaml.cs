﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace cw_24._04._2024_Client
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
