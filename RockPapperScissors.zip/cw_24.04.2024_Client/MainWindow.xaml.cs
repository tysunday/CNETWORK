﻿using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace cw_24._04._2024_Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        TcpClient tc;
        public MainWindow()
        {
            InitializeComponent();
         
        }

        private void SendButton_Click1(object sender, RoutedEventArgs e)
        {
            try
            {
                IPEndPoint endPoint = new IPEndPoint(
                    IPAddress.Parse("127.0.0.1"),
                    int.Parse("20000")
                    );
                tc = new TcpClient();
                tc.Connect(endPoint);
                NetworkStream nwStream = tc.GetStream();
                byte[] buffer = Encoding.Unicode.GetBytes(Choose1.Text);
                nwStream.Write(buffer, 0, buffer.Length);
                tc.Close();
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Socker Error:" + ex.Message);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);

            }
            finally
            {
                if (tc != null)
                    tc.Close();
            }
        }
        private void SendButton_Click2(object sender, RoutedEventArgs e)
        {
            try
            {
                IPEndPoint endPoint = new IPEndPoint(
                    IPAddress.Parse("127.0.0.1"),
                    int.Parse("20000")
                    );
                tc = new TcpClient();
                tc.Connect(endPoint);
                NetworkStream nwStream = tc.GetStream();
                byte[] buffer = Encoding.Unicode.GetBytes(Choose2.Text);
                nwStream.Write(buffer, 0, buffer.Length);
                tc.Close();
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Socker Error:" + ex.Message);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);

            }
            finally
            {
                if (tc != null)
                    tc.Close();
            }
        }
    }
}