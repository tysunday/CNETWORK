﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;

namespace cw_06._05._2024
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void SendMsg_Click(object sender, RoutedEventArgs e)
        {
            string url = URLTextBox.Text;

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(url);

                    if (response.IsSuccessStatusCode)
                    {
                        string html = await response.Content.ReadAsStringAsync();

                        string title = html.Substring(html.IndexOf("<title>") + 7);
                        title = title.Substring(0, title.IndexOf("</title>"));

                        int pTagCount = CountTags(html, "<p>");

                        string firstParagraph = GetFirstText(html);

                        ResultTextBox.Text = $"Заголовок сайта: {title}\n" +
                            $"Количество тэгов <p>: {pTagCount}\n" +
                            $"Первый абзац текста: {firstParagraph}";
                    }
                    else
                    {
                        ResultTextBox.Text = $"Ошибка: {(int)response.StatusCode} {response.ReasonPhrase}";
                    }
                }
            }
            catch (Exception ex)
            {
                ResultTextBox.Text = $"Ошибка: {ex.Message}";
            }
        }

        private int CountTags(string html, string tag)
        {
            int index = 0;
            int count = 0;
            while ((index = html.IndexOf(tag, index)) != -1)
            {
                index += tag.Length;
                count++;
            }
            return count;
        }

        private string GetFirstText(string html)
        {
            int startIndex = html.IndexOf('<');
            if (startIndex == -1)
                return "Текст не найден";

            int endIndex = html.IndexOf('>', startIndex);
            if (endIndex == -1)
                return "Текст не найден";

            string text = html.Substring(startIndex + 1, endIndex - startIndex - 1);

            text = text.Trim();

            if (text.Length == 0)
                return GetFirstText(html.Substring(endIndex + 1));

            return text;
        }

        private string RemoveTags(string input)
        {
            return System.Text.RegularExpressions.Regex.Replace(input, "<.*?>", String.Empty);
        }
    }
}
