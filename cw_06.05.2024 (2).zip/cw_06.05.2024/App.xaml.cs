﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace cw_06._05._2024
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
