﻿using System;
using System.Net;
using System.Windows;

namespace cw_06._05._2024
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SendMsg_Click(object sender, RoutedEventArgs e)
        {
            string url = URLTB.Text;

            try
            {
                WebClient client = new WebClient();
                string htmlCode = client.DownloadString(url);
                int tagCount = CountTags(htmlCode);
                string title = GetTitle(htmlCode);
                ResponseTB.Text = "Title: " + title + Environment.NewLine;
                ResponseTB.Text += "Tag count: " + tagCount;
            }
            catch (Exception ex)
            {
                ResponseTB.Text = "Error: " + ex.Message;
            }
        }

        private int CountTags(string html)
        {
            int count = 0;
            bool inTag = false;

            for (int i = 0; i < html.Length; i++)
            {
                if (html[i] == '<')
                {
                    inTag = true;
                }
                else if (html[i] == '>')
                {
                    inTag = false;
                    count++;
                }
            }

            return count;
        }

        private string GetTitle(string html)
        {
            int start = html.IndexOf("<title>");
            if (start == -1)
                return "No title found";

            start += "<title>".Length;
            int end = html.IndexOf("</title>", start);
            if (end == -1)
                return "No title found";

            return html.Substring(start, end - start).Trim();
        }
    }
}



//    public partial class MainWindow : Window
//    {
//        public MainWindow()
//        {
//            InitializeComponent();
//            HttpWebRequest hwr = (HttpWebRequest)WebRequest.Create("https://chel.top-academy.ru");
//            hwr.Headers.Add(HttpRequestHeader.AcceptLanguage, "ru-ru");

//            HttpWebResponse hwrr;
//            hwrr = (HttpWebResponse)hwr.GetResponse();
//            foreach(string header in hwrr.Headers)
//            {
//                Console.WriteLine(header);
//                Console.WriteLine(hwrr.Headers[header]);

//            }
//            StreamReader sr = new StreamReader(hwrr.GetResponseStream());
//            Console.WriteLine(sr.ReadToEnd());
//            sr.Close();
//            WebClient wc;
//            ServicePoint sp;
//            ServicePointManager spm;
//            Uri uri;
//            UriBuilder urib;

//            WebClient webClient = new WebClient();
//            byte[] urlData = webClient.DownloadData("http://top-academy.ru");
//            string page = Encoding.ASCII.GetString(urlData);
//            Console.WriteLine(page);

//            string fileCopy = "C:\\d.gif", urlString = "https://fs.top-academy.ru/api/v1/files/N0LNJfmCtV4UfT4xQvCjBNP9hBnt6-mR?inline=true?inline=true";
//            webClient.DownloadFile(urlString, fileCopy);

//            Stream copy = webClient.OpenRead(urlString);
//            FileInfo fl = new FileInfo(fileCopy);
//            StreamWriter sw = fl.CreateText();
//            sw.WriteLine(copy.ReadToEnd());
//            sw.Close();
//            copy.Close();

//            string textToUpload = "user=Admin&passwd=adminpass";
//            byte[] uploadData = Encoding.ASCII.GetBytes(textToUpload);
//            Stream upload = webClient.OpenWrite("http://top-academy.ru", "POST");
//            upload.Write(uploadData, 0, uploadData.Length);
//            upload.Close();

//            byte[] getData = webClient.UploadData("http://top-academy.ru", "GET", uploadData);
//        }
//    }
//}